﻿using IpmsEntityContext.Data.IRepository;
using IpmsEntityContext.DBContext;
using IpmsEntityContext.Helper;
using IpmsEntityModels.Models;
using IpmsShared.Models;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;

namespace IpmsEntityContext.Data.SqlRepository
{
    public class SqlClientRepository : IClientsRepository
    {
        private readonly AppDbContext _context;

        public SqlClientRepository(AppDbContext appDbContext)
        {
            this._context = appDbContext;

        }
        public Client Add(Client client)
        {
            //_context.Clients.Add(client);
            //_context.SaveChanges();
            //return client;

            throw new NotImplementedException();
        }

        public SqlResponseBaseModel AddClient(Client client)
        {
            SqlParameter[] param = new SqlParameter[8];
            SqlResponseBaseModel sqlResponse = new SqlResponseBaseModel();
            try
            {
                param[0] = new SqlParameter("@Actionid", SqlDbType.NVarChar, 4000);
                param[0].Value = 1;


                param[1] = new SqlParameter("@CcName", SqlDbType.NVarChar, 4000);
                param[1].Value = client.OrgnizationName;

                param[2] = new SqlParameter("@CcValue1", SqlDbType.NVarChar, 4000);
                param[2].Value = client.AbbrOfOrg;


                param[3] = new SqlParameter("@CcCrBy", SqlDbType.NVarChar, 4000);
                param[3].Value = client.CcCrBy;

                param[4] = new SqlParameter("@CcReferanceId", SqlDbType.Int);
                param[4].Value = client.TagWith;

                param[5] = new SqlParameter("@CcContactPersone", SqlDbType.NVarChar, 4000);
                param[5].Value = client.ContactPersonName.ToString();

                param[6] = new SqlParameter("@CcEmail", SqlDbType.NVarChar, 4000);
                param[6].Value = client.Email.ToString();

                param[7] = new SqlParameter("@CcMobile", SqlDbType.NVarChar, 4000);
                param[7].Value = client.MobileNo.ToString();

                DBHelper dbAccess = new DBHelper(AppDbContext.ConnectionString);

                sqlResponse = UtilityHelper.ConvertDataTableToList<SqlResponseBaseModel>(dbAccess.ExecuteDataSetSP(SqlProcedures.SPAddClients, param).Tables[0])[0];


            }
            catch (Exception ex)
            {

                throw;
            }
            return sqlResponse;
        }

        public Client Delete(int clientId)
        {
            throw new NotImplementedException();
            //Client client = _context.Clients.Find(clientId);
            //try
            //{
            //    if (client != null)
            //    {
            //        _context.Clients.Remove(client);
            //        _context.SaveChanges();
            //    }
            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}

            //return client;
        }

        public IEnumerable<Client> GetAllClients()
        {
            List<Client> Clients = new List<Client>();
            SqlParameter[] param = new SqlParameter[1];
            try
            {
                param[0] = new SqlParameter("@Actionid", SqlDbType.NVarChar, 4000);
                param[0].Value = 4;

                DBHelper dbAccess = new DBHelper(AppDbContext.ConnectionString);
                Clients = UtilityHelper.ConvertDataTableToList<Client>(dbAccess.ExecuteDataSetSP(SqlProcedures.SPAddClients, param).Tables[0]);
            }
            catch (Exception ex)
            {

                throw;
            }

            return Clients;
        }

        public Client GetClients(int id)
        {
            Client Clients = new Client();
            SqlParameter[] param = new SqlParameter[2];
            try
            {
                param[0] = new SqlParameter("@Actionid", SqlDbType.NVarChar, 4000);
                param[0].Value = 4;

                param[1] = new SqlParameter("@CcCode", SqlDbType.NVarChar, 4000);
                param[1].Value = id.ToString();

                DBHelper dbAccess = new DBHelper(AppDbContext.ConnectionString);
                Clients = UtilityHelper.ConvertDataTableToList<Client>(dbAccess.ExecuteDataSetSP(SqlProcedures.SPAddClients, param).Tables[0])[0];
            }
            catch (Exception ex)
            {

                throw;
            }

            return Clients;
        }

        public SqlResponseBaseModel Update(Client clientsChanges)
        {
            SqlParameter[] param = new SqlParameter[9];
            SqlResponseBaseModel sqlResponse = new SqlResponseBaseModel();
            try
            {
                param[0] = new SqlParameter("@Actionid", SqlDbType.NVarChar, 4000);
                param[0].Value = 2;


                param[1] = new SqlParameter("@CcName", SqlDbType.NVarChar, 4000);
                param[1].Value = clientsChanges.OrgnizationName;

                param[2] = new SqlParameter("@CcValue1", SqlDbType.NVarChar, 4000);
                param[2].Value = clientsChanges.AbbrOfOrg;


                param[3] = new SqlParameter("@CcCrBy", SqlDbType.NVarChar, 4000);
                param[3].Value = clientsChanges.CcCrBy;

                param[4] = new SqlParameter("@CcReferanceId", SqlDbType.Int);
                param[4].Value = clientsChanges.TagWith;

                param[5] = new SqlParameter("@CcContactPersone", SqlDbType.NVarChar, 4000);
                param[5].Value = clientsChanges.ContactPersonName.ToString();

                param[6] = new SqlParameter("@CcEmail", SqlDbType.NVarChar, 4000);
                param[6].Value = clientsChanges.Email.ToString();

                param[7] = new SqlParameter("@CcMobile", SqlDbType.NVarChar, 4000);
                param[7].Value = clientsChanges.MobileNo.ToString();

                param[8] = new SqlParameter("@CcCode", SqlDbType.NVarChar, 4000);
                param[8].Value = clientsChanges.Id.ToString();


                DBHelper dbAccess = new DBHelper(AppDbContext.ConnectionString);

                SqlResponseBaseModel dbresponse = UtilityHelper.ConvertDataTableToList<SqlResponseBaseModel>(dbAccess.ExecuteDataSetSP(SqlProcedures.SPAddClients, param).Tables[0])[0];


            }
            catch (Exception ex)
            {

                throw;
            }
            return sqlResponse;
        }


    }
}
