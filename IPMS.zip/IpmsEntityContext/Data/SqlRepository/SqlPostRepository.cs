﻿using IpmsEntityContext.Data.IRepository;
using IpmsEntityContext.DBContext;
using IpmsEntityContext.Helper;
using IpmsEntityModels.Models;
using IpmsShared.Models;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;

namespace IpmsEntityContext.Data.SqlRepository
{
    public class SqlPostRepository : IPostsRepository
    {
        private readonly AppDbContext _context;
        public SqlPostRepository(AppDbContext appDbContext)
        {
            this._context = appDbContext;
        }
        public SqlResponseBaseModel Add(Post post)
        {
            SqlParameter[] param = new SqlParameter[4];
            SqlResponseBaseModel dbresponse = new SqlResponseBaseModel();
            try
            {
                param[0] = new SqlParameter("@Actionid", SqlDbType.NVarChar, 4000);
                param[0].Value = 1;

                param[1] = new SqlParameter("@CcName", SqlDbType.NVarChar, 4000);
                param[1].Value = post.PostName;

                param[2] = new SqlParameter("@CcCrBy", SqlDbType.NVarChar, 4000);
                param[2].Value = post.CcCrBy;

                param[3] = new SqlParameter("@CcReferanceId", SqlDbType.NVarChar, 4000);
                param[3].Value = string.Join(',', post.OrgId);

                DBHelper dbAccess = new DBHelper(AppDbContext.ConnectionString);

                dbresponse = UtilityHelper.ConvertDataTableToList<SqlResponseBaseModel>(dbAccess.ExecuteDataSetSP(SqlProcedures.SPPosts, param).Tables[0])[0];


            }
            catch (Exception ex)
            {

                throw;
            }
            return dbresponse;
        }

        public Post Delete(int postId)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Post> GetAllPosts()
        {
            List<Post> Posts = new List<Post>();
            SqlParameter[] param = new SqlParameter[1];
            try
            {
                param[0] = new SqlParameter("@Actionid", SqlDbType.NVarChar, 4000);
                param[0].Value = 4;

                DBHelper dbAccess = new DBHelper(AppDbContext.ConnectionString);
                Posts = UtilityHelper.ConvertDataTableToList<Post>(dbAccess.ExecuteDataSetSP(SqlProcedures.SPPosts, param).Tables[0]);
            }
            catch (Exception ex)
            {

                throw;
            }

            return Posts;
        }

        public Post GetPost(int id)
        {
            Post Posts = new Post();
            SqlParameter[] param = new SqlParameter[2];
            try
            {
                param[0] = new SqlParameter("@Actionid", SqlDbType.NVarChar, 4000);
                param[0].Value = 5;

                param[1] = new SqlParameter("@CcCode", SqlDbType.NVarChar, 4000);
                param[1].Value = id.ToString();

                DBHelper dbAccess = new DBHelper(AppDbContext.ConnectionString);
                DataSet ds = dbAccess.ExecuteDataSetSP(SqlProcedures.SPPosts, param);
                if (ds.Tables.Count > 0)
                {
                    Posts = UtilityHelper.ConvertDataTableToList<Post>(ds.Tables[0])[0];
                }
               
            }
            catch (Exception ex)
            {

                throw;
            }

            return Posts;
        }

        public SqlResponseBaseModel Update(Post postChanges)
        {
            SqlParameter[] param = new SqlParameter[4];
            SqlResponseBaseModel dbresponse = new SqlResponseBaseModel();
            try
            {
                param[0] = new SqlParameter("@Actionid", SqlDbType.NVarChar, 4000);
                param[0].Value = 2;

                param[1] = new SqlParameter("@CcName", SqlDbType.NVarChar, 4000);
                param[1].Value = postChanges.PostName;

                param[2] = new SqlParameter("@CcCrBy", SqlDbType.NVarChar, 4000);
                param[2].Value = postChanges.CcCrBy;

                param[3] = new SqlParameter("@CcReferanceId", SqlDbType.NVarChar, 4000);
                param[3].Value = string.Join(',', postChanges.OrgId);

                DBHelper dbAccess = new DBHelper(AppDbContext.ConnectionString);

                dbresponse = UtilityHelper.ConvertDataTableToList<SqlResponseBaseModel>(dbAccess.ExecuteDataSetSP(SqlProcedures.SPPosts, param).Tables[0])[0];


            }
            catch (Exception ex)
            {

                throw;
            }
            return dbresponse;
        }
    }
}
