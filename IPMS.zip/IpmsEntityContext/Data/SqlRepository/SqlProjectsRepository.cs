﻿using IpmsEntityContext.Data.IRepository;
using IpmsEntityContext.DBContext;
using IpmsEntityModels.Models;
using System;
using System.Collections.Generic;

namespace IpmsEntityContext.Data.SqlRepository
{
    public class SqlProjectsRepository : IProjectRepository
    {
        private readonly AppDbContext _context;
        public SqlProjectsRepository(AppDbContext appDbContext)
        {
            this._context = appDbContext;
        }
        public Project Add(Project project)
        {
            throw new NotImplementedException();
        }

        public Project Delete(int projectId)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Project> GetAllProjects()
        {
            throw new NotImplementedException();
        }

        public Project GetProjects(int id)
        {
            throw new NotImplementedException();
        }

        public Project Update(Project projectsChanges)
        {
            throw new NotImplementedException();
        }
    }
}
