﻿using IpmsEntityContext.Data.IRepository;
using IpmsEntityContext.DBContext;
using IpmsEntityModels.Models;
using System;
using System.Collections.Generic;

namespace IpmsEntityContext.Data.SqlRepository
{
    public class SqlGradeRepository : IGradeRepository
    {
        private readonly AppDbContext _context;
        public SqlGradeRepository(AppDbContext appDbContext)
        {
            this._context = appDbContext;
        }
        public Grade Add(Grade grade)
        {
            //_context.Grades.Add(grade);
            //_context.SaveChanges();
            //return grade;
            throw new NotImplementedException();
        }

        public Grade Delete(int gradeId)
        {
            //Grade grade = _context.Grades.Find(gradeId);
            //try
            //{
            //    if (grade != null)
            //    {
            //        _context.Grades.Remove(grade);
            //        _context.SaveChanges();
            //    }
            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}

            //return grade;
            throw new NotImplementedException();
        }

        public IEnumerable<Grade> GetAllGrades()
        {
            //return _context.Grades;
            throw new NotImplementedException();
        }

        public Grade GetGrade(int id)
        {
            //return _context.Grades.Find(id);
            throw new NotImplementedException();
        }

        public Grade Update(Grade gradeChanges)
        {
            //var grade = _context.Grades.Attach(gradeChanges);
            //grade.State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            //_context.SaveChanges();

            //return gradeChanges;
            throw new NotImplementedException();
        }
    }
}
