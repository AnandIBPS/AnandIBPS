﻿using IpmsEntityModels.Models;
using System.Collections.Generic;

namespace IpmsEntityContext.Data.IRepository
{
    interface IProjectRepository
    {
        Project GetProjects(int id);
        IEnumerable<Project> GetAllProjects();
        Project Add(Project project);
        Project Update(Project projectsChanges);
        Project Delete(int projectId);
    }
}
