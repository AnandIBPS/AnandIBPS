﻿using IpmsEntityModels.Models;
using IpmsShared.Models;
using System.Collections.Generic;

namespace IpmsEntityContext.Data.IRepository
{
    public interface IClientsRepository
    {
        Client GetClients(int id);
        IEnumerable<Client> GetAllClients();
        Client Add(Client client);
        SqlResponseBaseModel Update(Client clientsChanges);
        Client Delete(int clientId);
        SqlResponseBaseModel AddClient(Client client);
    }
}
