﻿using IpmsEntityModels.Models;
using System.Collections.Generic;

namespace IpmsEntityContext.Data.IRepository
{
    public interface IGradeRepository
    {
        Grade GetGrade(int id);
        IEnumerable<Grade> GetAllGrades();
        Grade Add(Grade grade);
        Grade Update(Grade gradeChanges);
        Grade Delete(int gradeId);
    }
}
