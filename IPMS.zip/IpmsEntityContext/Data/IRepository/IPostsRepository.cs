﻿using IpmsEntityModels.Models;
using IpmsShared.Models;
using System.Collections.Generic;

namespace IpmsEntityContext.Data.IRepository
{
    public interface IPostsRepository
    {
        Post GetPost(int id);
        IEnumerable<Post> GetAllPosts();
        SqlResponseBaseModel Add(Post post);
        SqlResponseBaseModel Update(Post postChanges);
        Post Delete(int postId);


    }
}
