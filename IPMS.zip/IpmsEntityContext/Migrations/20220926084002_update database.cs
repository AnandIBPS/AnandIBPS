﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace IpmsEntityContext.Migrations
{
    public partial class updatedatabase : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetUserRoles",
                keyColumns: new[] { "RoleId", "UserId" },
                keyValues: new object[] { "127acc75-05ae-4c2a-bf41-21ee982c23b3", "3fff101c-43e2-4b02-aa70-8d200827664e" });

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "127acc75-05ae-4c2a-bf41-21ee982c23b3");

            migrationBuilder.DeleteData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "3fff101c-43e2-4b02-aa70-8d200827664e");

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[] { "679f7107-a989-4c33-8d57-6dcedf83dc48", "e2c278d8-4639-4ed6-bfea-741c40f49703", "System", "SYSTEM" });

            migrationBuilder.InsertData(
                table: "AspNetUsers",
                columns: new[] { "Id", "AccessFailedCount", "ConcurrencyStamp", "Department", "Email", "EmailConfirmed", "EmployeeId", "LockoutEnabled", "LockoutEnd", "NormalizedEmail", "NormalizedUserName", "PasswordHash", "PhoneNumber", "PhoneNumberConfirmed", "SecurityStamp", "TwoFactorEnabled", "UserName" },
                values: new object[] { "759a74d0-ed9f-4ce0-aa78-890a3c37daed", 0, "128ec30b-e2f8-456d-a292-e6981025c362", "System", "superadmin@ibps.in", false, "0", false, null, "SUPERADMIN@IBPS.IN", "SUPERADMIN@IBPS.IN", "AQAAAAEAACcQAAAAEClZ4KvbqV2rdKPZWccW4CwKnJQIUCSHsMWvsXkpHtKly1ByOFn72OPUsPvjXcyXpg==", null, false, "d14e6be3-6a84-49a3-bcad-e39a9f4d00e7", false, "superadmin@ibps.in" });

            migrationBuilder.InsertData(
                table: "AspNetUserRoles",
                columns: new[] { "RoleId", "UserId" },
                values: new object[] { "679f7107-a989-4c33-8d57-6dcedf83dc48", "759a74d0-ed9f-4ce0-aa78-890a3c37daed" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetUserRoles",
                keyColumns: new[] { "RoleId", "UserId" },
                keyValues: new object[] { "679f7107-a989-4c33-8d57-6dcedf83dc48", "759a74d0-ed9f-4ce0-aa78-890a3c37daed" });

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "679f7107-a989-4c33-8d57-6dcedf83dc48");

            migrationBuilder.DeleteData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "759a74d0-ed9f-4ce0-aa78-890a3c37daed");

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[] { "127acc75-05ae-4c2a-bf41-21ee982c23b3", "0fafebd1-b6ed-4a70-b9d1-48f6dd35c4cc", "System", "SYSTEM" });

            migrationBuilder.InsertData(
                table: "AspNetUsers",
                columns: new[] { "Id", "AccessFailedCount", "ConcurrencyStamp", "Department", "Email", "EmailConfirmed", "EmployeeId", "LockoutEnabled", "LockoutEnd", "NormalizedEmail", "NormalizedUserName", "PasswordHash", "PhoneNumber", "PhoneNumberConfirmed", "SecurityStamp", "TwoFactorEnabled", "UserName" },
                values: new object[] { "3fff101c-43e2-4b02-aa70-8d200827664e", 0, "00caa879-2af2-47c1-bd72-564bf5d1b43b", "System", "superadmin@ibps.in", false, "0", false, null, null, null, "AQAAAAEAACcQAAAAEAVfHOxGN1EBC1Ky5h9F6NYofQqvcB6ATgogzDb3HL7lhKQMZcR9KjvXczx/PQ3uhA==", null, false, "72bfd2b5-9168-4ac4-b19d-0085ff860a75", false, "superadmin@ibps.in" });

            migrationBuilder.InsertData(
                table: "AspNetUserRoles",
                columns: new[] { "RoleId", "UserId" },
                values: new object[] { "127acc75-05ae-4c2a-bf41-21ee982c23b3", "3fff101c-43e2-4b02-aa70-8d200827664e" });
        }
    }
}
