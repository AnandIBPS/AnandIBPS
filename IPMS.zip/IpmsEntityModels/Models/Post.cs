﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace IpmsEntityModels.Models
{
    public class Post : UserData
    {
        public int PostId { get; set; }
        public string PostName { get; set; }
        public List<string> OrgId { get; set; }
        public string OrgName { get; set; }
        public Post()
        {
            OrgId = new List<string>();
        }
    }

}
