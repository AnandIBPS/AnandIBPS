﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace IpmsEntityModels.Models
{
    public class Project
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ProjectId { get; set; }
        public string ProjectNo { get; set; }
        public int ClientId { get; set; }
        public int ProjectFor { get; set; } // Promotion or Recruitment
        public int HandledBy { get; set; } // IBPS Or Banks Or Both
        public List<GradeForProject> Grades { get; set; }
        public List<PostForProject> Posts { get; set; }
        public bool IsQualificationDetailsRequired { get; set; }
        public string QualificationDetailsFilePath { get; set; }
        public bool IsExperienceDetailsRequired { get; set; }
        public string ExperienceDetailsFilePath { get; set; }
        public DateTime DateOfExams { get; set; }
        public string CandidateReportingTime { get; set; }
        public string TypeOfTest { get; set; }
        public string RollNoStructure { get; set; }
        public bool IsMultiPostAdditionalTest { get; set; }
        public long NumberOfCandidate { get; set; }
        public bool IsPenaltyofWrongAns { get; set; }
        [Column(TypeName = "decimal(18,2)")]
        public decimal MarksDeducted { get; set; }
        public int NoofQuestionForDeduction { get; set; }
        public int NoOfAnswerInQuestion { get; set; }
        public string DispatchMode { get; set; }
        public DateTime ResultOn { get; set; }
        public bool IsHandWritingSample { get; set; }
        public List<AdditionalserviceForProject> Additionalservice { get; set; }
        public Post Client { get; set; }
    }
    public class GradeForProject
    {
        //public int ProjectId { get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int GradeId { get; set; }
        public string GradeName { get; set; }
        public string ProjectId { get; set; }
    }

    public class PostForProject
    {
        //public int ProjectId { get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int PostId { get; set; }
        public string PostName { get; set; }
        public string ProjectId { get; set; }

    }
    public class AdditionalserviceForProject
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int AdditionalserviceId { get; set; }
        public string AdditionalserviceName { get; set; }
        public string ProjectId { get; set; }
    }

}
