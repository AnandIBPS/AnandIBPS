﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

using System.Linq;
using System.Threading.Tasks;

namespace IpmsEntityModels.Models
{
    public class Client: UserData
    {        
        public int Id { get; set; }       
        public string OrgnizationName { get; set; }
        public string ContactPersonName { get; set; }
        public string Email { get; set; }
        public string MobileNo { get; set; }
        public int TagWith { get; set; }
        public string AbbrOfOrg { get; set; }
    }
}
