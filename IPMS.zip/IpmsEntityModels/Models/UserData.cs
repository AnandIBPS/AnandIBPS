﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IpmsEntityModels.Models
{
    public class UserData
    {
        public string CcCrBy { get; set; }
    }
}
