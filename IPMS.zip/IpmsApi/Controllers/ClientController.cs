﻿using IpmsApi.Filters;
using IpmsEntityContext.Data.IRepository;
using IpmsEntityModels.Models;
using IpmsShared.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IpmsApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [CustomAuthorization]
    public class ClientController : ControllerBase
    {
        private readonly ILogger<ClientController> _logger;
        private readonly IClientsRepository _ClientsRepository;
        public ClientController(ILogger<ClientController> logger, IClientsRepository ClientsRepository)
        {
            _logger = logger;
            _ClientsRepository = ClientsRepository;
        }
        [HttpGet]
        [Route("GetClient/{id}")]
        public async Task<ActionResult<Client>> GetClient(int id)
        {
            try
            {
                return Ok(_ClientsRepository.GetClients(id));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetClient");
                return BadRequest(ex);
            }
        }
        [HttpPost]
        [Route("SaveClient")]
        public async Task<ActionResult<ApiResponse>> SaveClient(Client client)
        {
            SqlResponseBaseModel sqlResponseBaseModel = new SqlResponseBaseModel();
            ApiResponse apiResponse = new ApiResponse();
            try
            {
                sqlResponseBaseModel = _ClientsRepository.AddClient(client);
                if (sqlResponseBaseModel.ErrorCode==0)
                {
                    apiResponse.Status = 1;
                    apiResponse.StatusMessage = "Data inserted successfully!!";

                }
                else
                {
                    apiResponse.Status = 0;
                    apiResponse.StatusMessage = sqlResponseBaseModel.Message;
                }
                //Client objClient = _ClientsRepository.Add(client);
                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "SaveClient");
                return BadRequest(ex);
            }
        }

        [HttpPost]
        [Route("UpdateClient")]
        public async Task<ActionResult<Client>> UpdateClient(Client client)
        {
            SqlResponseBaseModel sqlResponseBaseModel = new SqlResponseBaseModel();
            ApiResponse apiResponse = new ApiResponse();
            try
            {
                sqlResponseBaseModel = _ClientsRepository.Update(client);
                if (sqlResponseBaseModel.ErrorCode == 0)
                {
                    apiResponse.Status = 1;
                    apiResponse.StatusMessage = "Data inserted successfully!!";

                }
                else
                {
                    apiResponse.Status = 0;
                    apiResponse.StatusMessage = sqlResponseBaseModel.Message;
                }
                //Client objClient = _ClientsRepository.Add(client);
                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UpdateClient");
                return BadRequest(ex);
            }
        }
        [HttpGet]
        [Route("GetClientList")]
        
        public async Task<ActionResult<List<Client>>> GetClientList()
        {
            try
            {
                return Ok(_ClientsRepository.GetAllClients());
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetClient");
                return BadRequest(ex);
            }
        }
    }
}
