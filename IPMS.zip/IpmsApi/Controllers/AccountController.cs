﻿
using IpmsApi.Filters;
using IpmsApi.TokenRepository;
using IpmsEntityModels.Models;
using IpmsShared.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace IpmsApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [CustomAuthorization]
    public class AccountController : ControllerBase
    {
        private readonly ILogger<AccountController> _logger;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly ITokenService _tokenService;
        private readonly IConfiguration _config;

        public AccountController(ILogger<AccountController> logger, UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager, IConfiguration configuration, ITokenService tokenService)
        {
            this._logger = logger;
            this._userManager = userManager;
            this._signInManager = signInManager;
            this._config = configuration;
            this._tokenService = tokenService;
        }
        [HttpPost]
        [Route("Register")]
        [AllowAnonymous]
        public async Task<ActionResult<ApiResponse<string>>> Register(RegisterModel model)
        {
            ApiResponse<string> response = new ApiResponse<string>();
            try
            {
                if (!string.IsNullOrEmpty(model.EmailId) && !string.IsNullOrEmpty(model.EmployeeId) && !string.IsNullOrEmpty(model.Department) && !string.IsNullOrEmpty(model.Password))
                {
                    var applicationUser = new ApplicationUser { Email = model.EmailId, UserName = model.EmailId, Department = model.Department, EmployeeId = model.EmployeeId };
                    var result = await _userManager.CreateAsync(applicationUser, model.Password);
                    if (result.Succeeded)
                    {
                        var EmailVerificationToken = await _userManager.GenerateEmailConfirmationTokenAsync(applicationUser);

                        response.Message = new AppMessage { Code = EmailVerificationToken.ToString(), Text = "User Created Successfully. Please validate your email." };
                        response.Data = applicationUser.Id;
                        response.Status = 1;
                        response.StatusMessage = "success";
                    }
                    else
                    {
                        string errorMessage = "";
                        foreach (var error in result.Errors)
                        {
                            errorMessage += error.Description + "\n";
                        }
                        response.StatusMessage = "failure";
                        response.Message = new AppMessage { Text = errorMessage };
                    }
                }
                else
                {
                    response.StatusMessage = "failure";
                    response.Message = new AppMessage { Text = "Validation failed!!!" };
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Register");
                response.StatusMessage = "failure";
                response.Message = new AppMessage { Text = ex.InnerException.Message };
            }
            return Ok(response);
        }

        [HttpPost]
        [Route("Login")]
        [AllowAnonymous]
        public async Task<ActionResult<ApiResponse<LoginResponse>>> Login(LoginUserInfo model)
        {
            ApiResponse<LoginResponse> response = new ApiResponse<LoginResponse>();
            try
            {
                if (!string.IsNullOrEmpty(model.LoginId) && !string.IsNullOrEmpty(model.Password))
                {

                    var _user = await _userManager.FindByEmailAsync(model.LoginId);

                    if (_user != null && !_user.EmailConfirmed && (await _userManager.CheckPasswordAsync(_user, model.Password)))
                    {
                        response.StatusMessage = "failure";
                        response.Message = new AppMessage { Text = "Kindly confirm your email to login." };
                        return Ok(response);
                    }
                    else
                    {
                        var result = await _signInManager.PasswordSignInAsync(model.LoginId, model.Password, model.IsRememberMe, false);
                        if (result.Succeeded)
                        {
                            LoginResponse loginAPIResponseModel = new LoginResponse();

                            var user = _userManager.FindByNameAsync(model.LoginId).Result;


                            loginAPIResponseModel.UserId = user.Id;
                            loginAPIResponseModel.UserName = user.UserName;
                            loginAPIResponseModel.EmailId = user.Email;
                            loginAPIResponseModel.EmployeeCode = user.EmployeeId;
                            loginAPIResponseModel.DepartmentCode = user.Department;

                            var claims = new List<Claim> {
                            new Claim(ClaimTypes.NameIdentifier, user.Id)
                        };
                            var userRoles = _userManager.GetRolesAsync(user).Result;
                            foreach (var role in userRoles)
                            {
                                claims.Add(new Claim(ClaimTypes.Role, role.ToString()));
                                loginAPIResponseModel.UserType.Add(role.ToString());
                            }

                            loginAPIResponseModel.AuthToken = _tokenService.BuildToken(_config["Jwt:Key"].ToString(), _config["Jwt:Issuer"].ToString(), _userManager.FindByNameAsync(model.LoginId).Result, claims);



                            response.Data = loginAPIResponseModel;
                            response.Message = new AppMessage { Text = "Signed in Successfully." };
                            response.Status = 1;
                            response.StatusMessage = "success";

                        }
                        else
                        {
                            response.StatusMessage = "failure";
                            response.Message = new AppMessage { Text = "Invalid login Attempt!!!" };
                        }
                    }

                }
                else
                {
                    response.StatusMessage = "failure";
                    response.Message = new AppMessage { Text = "Invalid login Attempt!!!" };
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Register");
                response.StatusMessage = "failure";
                response.Message = new AppMessage { Text = ex.Message.ToString() };
            }
            return Ok(response);
        }

        [HttpGet]
        [Route("IsEmailExists")]
        [AllowAnonymous]
        public async Task<ActionResult<ApiResponse>> IsEmailInUse(string email)
        {
            var user = await _userManager.FindByEmailAsync(email);
            ApiResponse apiResponse = new ApiResponse();
            if (user == null)
            {
                apiResponse.Status = 1;
            }
            else
            {
                apiResponse.Status = 0;

            }
            return apiResponse;
        }

        [AllowAnonymous]
        [Route("ConfirmEmail")]
        [HttpGet]
        public async Task<ActionResult<ApiResponse<string>>> ConfirmEmail(string userId, string token)
        {
            ApiResponse<string> apiResponse = new ApiResponse<string>();
            if (userId == null || token == null)
            {
                return new ApiResponse<string> { Status = 0, Message = new AppMessage { Text = "User or token not valid" } };
            }

            var user = await _userManager.FindByIdAsync(userId);
            if (user == null)
            {
                return new ApiResponse<string> { Status = 0, Message = new AppMessage { Text = "User not found" } };
            }

            var result = await _userManager.ConfirmEmailAsync(user, token);
            if (result.Succeeded)
            {
                apiResponse.Status = 1;
                apiResponse.StatusMessage = "Email successfully confirmed. Kindly Login and change your password for security reason.";
            }
            else
            {
                apiResponse.Status = 0;
                apiResponse.StatusMessage = result.Errors.FirstOrDefault().ToString();
            }

            return apiResponse;
        }

    }
}
