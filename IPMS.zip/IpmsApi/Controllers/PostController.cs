﻿using IpmsEntityContext.Data.IRepository;
using IpmsEntityModels.Models;
using IpmsShared.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IpmsApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PostController : ControllerBase
    {
        private readonly ILogger<PostController> _logger;
        private readonly IPostsRepository _PostRepository;
        public PostController(ILogger<PostController> logger, IPostsRepository PostRepository)
        {
            _logger = logger;
            _PostRepository = PostRepository;
        }
        [HttpGet]
        [Route("GetPost/{id}")]
        public async Task<ActionResult<Post>> GetPost(int id)
        {
            try
            {
                return Ok(_PostRepository.GetPost(id));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetPost");
                return BadRequest(ex);
            }
        }
        [HttpPost]
        [Route("SavePost")]
        public async Task<ActionResult<ApiResponse>> SavePost(Post objPost)
        {
            SqlResponseBaseModel sqlResponseBaseModel = new SqlResponseBaseModel();
            ApiResponse apiResponse = new ApiResponse();
            try
            {
                sqlResponseBaseModel = _PostRepository.Add(objPost);
                if (sqlResponseBaseModel.ErrorCode == 0)
                {
                    apiResponse.Status = 1;
                    apiResponse.StatusMessage = "Data inserted successfully!!";

                }
                else
                {
                    apiResponse.Status = 0;
                    apiResponse.StatusMessage = sqlResponseBaseModel.Message;
                }

                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "SavePost");
                return BadRequest(ex);
            }

        }
        [HttpPost]
        [Route("UpdatePost")]
        public async Task<ActionResult<ApiResponse>> UpdatePost(Post objPost)
        {
            SqlResponseBaseModel sqlResponseBaseModel = new SqlResponseBaseModel();
            ApiResponse apiResponse = new ApiResponse();
            try
            {
                sqlResponseBaseModel = _PostRepository.Update(objPost);
                if (sqlResponseBaseModel.ErrorCode == 0)
                {
                    apiResponse.Status = 1;
                    apiResponse.StatusMessage = "Data Updated successfully!!";

                }
                else
                {
                    apiResponse.Status = 0;
                    apiResponse.StatusMessage = sqlResponseBaseModel.Message;
                }

                return Ok(apiResponse);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UpdatePost");
                return BadRequest(ex);
            }

        }
        [HttpGet]
        [Route("GetPostList")]
        public async Task<ActionResult<List<Post>>> GetPostList()
        {
            try
            {
                return Ok(_PostRepository.GetAllPosts());
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetPostList");
                return BadRequest(ex);
            }
        }
    }
}
