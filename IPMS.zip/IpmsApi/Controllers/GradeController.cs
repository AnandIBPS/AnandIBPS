﻿using IpmsEntityContext.Data.IRepository;
using IpmsEntityModels.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IpmsApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GradeController : ControllerBase
    {
        private readonly ILogger<GradeController> _logger;
        private readonly IGradeRepository _GradeRepository;
        public GradeController(ILogger<GradeController> logger, IGradeRepository GradeRepository)
        {
            _logger = logger;
            _GradeRepository = GradeRepository;
        }
        [HttpGet]
        [Route("GetGrade/{id}")]
        public async Task<ActionResult<Grade>> GetGrade(int id)
        {
            try
            {
                return Ok(_GradeRepository.GetGrade(id));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetGrade");
                return BadRequest(ex);
            }
        }
        [HttpPost]
        [Route("SaveGrade")]
        public async Task<ActionResult<Grade>> SaveGrade(Grade objGrade)
        {
            try
            {
                Grade grade = _GradeRepository.Add(objGrade);
                return Ok(grade);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "SaveGrade");
                return BadRequest(ex);
            }
        }

        [HttpPost]
        [Route("UpdateGrade")]
        public async Task<ActionResult<Grade>> UpdateGrade(Grade objGrade)
        {
            try
            {
                Grade grade = _GradeRepository.Update(objGrade);
                return Ok(grade);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UpdateGrade");
                return BadRequest(ex);
            }
        }
        [HttpGet]
        [Route("GetGradeList")]
        public async Task<ActionResult<List<Client>>> GetGradeList()
        {
            try
            {
                return Ok(_GradeRepository.GetAllGrades());
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetGradeList");
                return BadRequest(ex);
            }
        }
    }
}
