﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IpmsShared.Helpers
{
    public static class UtilityHelper
    {
        private static Random random = new Random();
        private static string alphaCaps = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        private static string alphaLow = "abcdefghijklmnopqrstuvwxyz";
        private static string numerics = "1234567890";
        private static string special = "@#$-=^";
        private static string allChars = alphaCaps + alphaLow + numerics + special;
     
        public static string RandomString(int length)
        {
            String generatedPassword = "";

            int lowerpass, upperpass, numpass, specialchar;
            string posarray = "0123456789";
            if (length < posarray.Length)
                posarray = posarray.Substring(0, length);
            lowerpass = getRandomPosition(ref posarray);
            upperpass = getRandomPosition(ref posarray);
            numpass = getRandomPosition(ref posarray);
            specialchar = getRandomPosition(ref posarray);


            for (int i = 0; i < length; i++)
            {
                if (i == lowerpass)
                    generatedPassword += getRandomChar(alphaCaps);
                else if (i == upperpass)
                    generatedPassword += getRandomChar(alphaLow);
                else if (i == numpass)
                    generatedPassword += getRandomChar(numerics);
                else if (i == specialchar)
                    generatedPassword += getRandomChar(special);
                else
                    generatedPassword += getRandomChar(allChars);
            }
            return generatedPassword;
        }

        private static string getRandomChar(string fullString)
        {
            return fullString.ToCharArray()[(int)Math.Floor(random.NextDouble() * fullString.Length)].ToString();
        }

        private static int getRandomPosition(ref string posArray)
        {
            int pos;
            string randomChar = posArray.ToCharArray()[(int)Math.Floor(random.NextDouble() * posArray.Length)].ToString();
            pos = int.Parse(randomChar);
            posArray = posArray.Replace(randomChar, "");
            return pos;
        }







        

        //public static string RandomString(int length)
        //{
        //    const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%!^";
        //    return new string(Enumerable.Repeat(chars, length)
        //        .Select(s => s[random.Next(s.Length)]).ToArray());
        //}
     
    }
}
