﻿namespace IpmsShared
{
    public class SharedResource
    {
        ///No property or method defined in this class. 
        ///This class is declared for handling shared resources across the application.
    }
}
