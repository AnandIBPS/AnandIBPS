﻿$(document).ready(function () {
    $('button[type="submit"]').click(function (e) {
        e.preventDefault();

        var idofbtn = $(this).attr("id");
        var formid = $(this).parent("form").attr("id");

        if ($('form').valid()) {
            switch ($(this).data("usefor").toLowerCase()) {
                case "create":
                    Swal.fire({
                        title: 'Are you sure?',
                        text: "You want to save the data",
                        icon: 'information',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, Save it!',
                        backdrop: false
                    }).then((result) => {
                        if (result.isConfirmed) {
                            $('form').submit();
                        }
                    });
                    break;
                case "edit":
                    Swal.fire({
                        title: 'Are you sure?',
                        text: "You want to modify the existing data",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, Modify it!',
                        backdrop: false
                    }).then((result) => {
                        if (result.isConfirmed) {
                            $('form').submit();
                        }
                    });
                    break;
                case "del":
                    Swal.fire({
                        title: 'Are you sure?',
                        text: "You want to delete data? You won't have access of the data anymore",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#d33',
                        cancelButtonColor: '#3085d6',
                        confirmButtonText: 'Yes, Delete it!',
                        backdrop: false
                    }).then((result) => {
                        if (result.isConfirmed) {
                            $($(this).parent("form")).submit();
                        }
                    });
                    break;
                default:
                    $('form').submit();
            }



        }

    });

});