﻿$(document)
    .ready(function () {
        //fnSetMandatoryClass();
        //resizeLoader();
        //showPageLoader();
        //$('select').select2();
        $('.showMoreInfo')
            .on('show.bs.collapse', function () {
                $("a[href='#" + $(this)[0].id + "']").html("<i class='fas fa-chevron-up'></i>Hide");
            })
            .on('hide.bs.collapse', function () {
                $("a[href='#" + $(this)[0].id + "']").html("<i class='fas fa-chevron-down'></i>More");
            });

        $(window).resize(function () {
            resizeLoader();
        });

        $("button[type='submit']").click(function () {
            showPageLoader();
        });

        $("input[type='submit']").click(function () {
            showPageLoader();
        });

        $('form').bind('invalid-form.validate', function (error, element) {
            hidePageLoader();
            var varTitle = "Please correct the following error";
            if (element.currentElements.length > 1) {
                varTitle = "Please correct the following errors";
            }

            var varErrorHtml = "<ul>";
            $.each(element.errorList, function (index, value) {
                varErrorHtml += "<li>" + value.message + "</li>";
            });

            varErrorHtml += "</ul>";
            try {
                Swal.fire({
                    title: '<h5 class="text-primary">' + varTitle + '</h5>',
                    html: varErrorHtml,
                    customClass: {
                        icon: 'swalIcon',
                        confirmButton: 'btnSwalConfirm btn-sm'
                    }
                }).then((result) => {
                    if (element.currentElements.length > 0) {
                        var varElement = element.currentElements[0].id;
                        if (varElement !== undefined && varElement !== "") {
                            setTimeout(function () {
                                $("#" + varElement).focus();
                            }, 500);
                        }
                    }
                });
            }
            catch (err) {
                ShowMessage("Exception", err.message, "error");
            }
        });


        $(".without-border").click(function (sender) {
            if ($(this).toggleClass("expanded").attr("aria-expanded") === "true") {
                $(this).toggleClass("expanded").find("i").removeClass("fa fa-minus");
                $(this).toggleClass("expanded").find("i").addClass("fa fa-plus");
            } else {
                $(this).toggleClass("expanded").find("i").removeClass("fa fa-plus");
                $(this).toggleClass("expanded").find("i").addClass("fa fa-minus");
            }
        });

        $(".with-border").click(function (sender) {
            var ToggleCount = 0;
            var CurrentTarget = $(this).toggleClass("expanded").attr("data-target");
            if ($(this).toggleClass("expanded").attr("aria-expanded") === "true") {
                $(this).toggleClass("expanded").find("i").removeClass("fa fa-minus");
                $(this).toggleClass("expanded").find("i").addClass("fa fa-plus");
                $.each($(".with-border"), function (i, data) {
                    if ($(data).attr("data-target") === CurrentTarget) {
                        var a = 0;
                    }
                    else {
                        if ($(data).attr("aria-expanded") === "true")
                            ToggleCount++;
                    }
                });
                if (ToggleCount === 0) {
                    $("#ToggleAllBtn").attr("aria-expanded", "false")
                    $("#ToggleAllBtn").html('');
                    $("#ToggleAllBtn").append("<i class='fa fa-plus' style='margin-right:5px'></i>Expand All");
                };
            } else {
                $(this).toggleClass("expanded").find("i").removeClass("fa fa-plus");
                $(this).toggleClass("expanded").find("i").addClass("fa fa-minus");
                $("#ToggleAllBtn").attr("aria-expanded", "true")
                $("#ToggleAllBtn").html('');
                $("#ToggleAllBtn").append("<i class='fa fa-minus' style='margin-right:5px'></i>Toggle All");
            }

        });
        // to hide loader once page gets loaded
        $('div.spanner').delay(250).queue(function (next) {
            //$(this).removeClass('show');
            hidePageLoader();
            next();
        });

        $(document).on('focus', '.select2-selection.select2-selection--single', function (e) {
            $(this).closest(".select2-container").siblings('select:enabled').select2('open');
        });

        // steal focus during close - only capture once and stop propogation
        $('select.select2').on('select2:closing', function (e) {
            $(e.target).data("select2").$selection.one('focus focusin', function (e) {
                e.stopPropagation();
            });
        });

    })
    .ajaxStart(function () {
        showPageLoader();
    }).ajaxSuccess(function () {
        hidePageLoader();
    }).
    ajaxError(function () {
        hidePageLoader();
    })
    .ajaxStop(function () {
        hidePageLoader();
    });

fnRedirectPlainLink = function (sender) {
    try {
        showPageLoader();
        $(window).attr('location', $(sender).attr("data-url"));
    }
    catch (err) {
        hidePageLoader();
        ShowHtmlMessage("Exception", err.message, "error");
    }
};

fnSetMandatoryClass = function () {
    try {
        var elementName = arguments.length > 0 ? arguments[0] : null;
        if (elementName === null) {
            $("*[data-val-required]").each(function (index) {
                $("label[for='" + $(this).attr("name") + "']").each(function (idx) {
                    $(this).addClass("mandatory");
                });
            });
        }
        else {
            $("*[name='" + elementName + "']").each(function (index) {
                var required = $(this).attr("data-val-required");

                $("label[for='" + $(this).attr("name") + "']").each(function (idx) {
                    if (required && required !== undefined && required !== "") {
                        $(this).addClass("mandatory");
                    }
                    else {
                        $(this).removeClass("mandatory");
                    }
                });
            });
        }

    } catch (err) {
        ShowHtmlMessage("Exception", err.message, "error");
    }
};

fnRedirectLink = function (sender) {
    try {
        var redirectUrl = fnEncryptParam($(sender).attr("data-url"));
        showPageLoader();
        $(window).attr('location', redirectUrl);
    }
    catch (err) {
        hidePageLoader();
        ShowHtmlMessage("Exception", err.message, "error");
    }
};

fnRedirectGridUrl = function (Url) {
    try {
        var redirectUrl = fnEncryptParam(Url);
        showPageLoader();
        $(window).attr('location', redirectUrl);
    }
    catch (err) {
        hidePageLoader();
        ShowHtmlMessage("Exception", err.message, "error");
    }
};

fnEncryptParam = function (url) {
    try {
        var varUrl = url;
        $.ajax({
            type: "GET",
            contentType: "html",
            async: false,
            url: "/Base/GetEncryptedUrl",
            data: { pUrl: url },
            success: function (response) {
                varUrl = response;
            },
            error: function (response) {
                ShowHtmlMessage("Exception", JSON.stringify(response), "error");
            }
        });
        return varUrl;
    }
    catch (err) {
        ShowHtmlMessage("Exception", err.message, "error");
    }
};

rebindGrid = function (gridId) {
    $("#" + gridId).jsGrid("loadData");
};

ShowMessage = function (msgTitle, msgText, msgType) {
    try {
        var isConfirm = false;
        switch (msgType) {
            case "success": {
                msgTitle = msgTitle === "" ? "Success !" : msgTitle;
            } break;
            case "error": {
                msgTitle = msgTitle === "" ? "Error !" : msgTitle;
                isConfirm = true;
            } break;
            case "info": {
                msgTitle = msgTitle === "" ? "Information !" : msgTitle;
            } break;
            case "warning": {
                msgTitle = msgTitle === "" ? "Warning !" : msgTitle;
                isConfirm = true;
            } break;
            case "question": {
                msgTitle = msgTitle === "" ? "Question !" : msgTitle;
                isConfirm = true;
            } break;
        }

        if (isConfirm) {
            Swal.fire({
                type: msgType,
                title: msgTitle,
                html: msgText
            });
        }
        else {
            Swal.fire({
                type: msgType,
                title: msgTitle,
                html: msgText,
                timer: 1500,
                showCancelButton: false,
                showConfirmButton: false
            }).then(function (dismiss) { if (dismiss === 'timer') { } });
        }

    }
    catch (err) {
        alert(err.message);
    }
};

ShowHtmlMessage = function (msgTitle, msgText, msgType) {
    ShowMessage(msgTitle, msgText, msgType);
};

showPageLoader = function () {
    if ($("div.spanner") && !$("div.spanner").hasClass("show")) {
        $("div.spanner").addClass("show");
    }
};

hidePageLoader = function () {
    if ($("div.spanner") && $("div.spanner").hasClass("show")) {
        $("div.spanner").removeClass("show");
    }
};

resizeLoader = function () {

    var element = $('div.spanner div.loader');
    var w_width = $(window).width();
    var w_height = $(window).height();
    var resized_width = element.width();
    var resized_height = element.height();

    var top_position = (w_height / 2) - (resized_height / 2);
    var left_position = (w_width / 2) - (resized_width / 2);
    element.css({ 'top': top_position, 'left': left_position });
};

getGridItem = function (gridId) {
    return $("#" + gridId).jsGrid("_getCurrentRowItem");
};

setGridItem = function (gridId, setfield, value) {
    return $("#" + gridId).jsGrid("_setCurrentRowItem", setfield, value);
};

setGridLovCode = function (gridId, setfield, value) {
    return $("#" + gridId).jsGrid("_setCurrentRowLovCode", setfield, value);
};

setGridColumnType = function (gridId, setfield, value) {
    return $("#" + gridId).jsGrid("_setCurrentRowType", setfield, value);
};

setItemProperty = function (gridId, setfield, value) {
    return $("#" + gridId).jsGrid("_setCurrentRowProp", setfield, value);
};

setMinDate = function (fieldId, value) {
    $("#" + fieldId)[0].parentNode._flatpickr.set("minDate", value);
};

setMaxDate = function (fieldId, value) {
    $("#" + fieldId)[0].parentNode._flatpickr.set("maxDate", value);
};

setDate = function (fieldId, value) {
    var config = $("#" + fieldId)[0].parentNode._flatpickr.config;
    $("#" + fieldId)[0].parentNode._flatpickr.setDate(value, true, config.dateFormat);
};

fnFillGridDropdown = function (gridId, setfield, value) {
    return $("#" + gridId).jsGrid("_fnGridFillDropdown", setfield, value);
};

GridAjaxDone = function (response) {
    try {
        var varMessageType = (response.Status === 1 ? "success" : "error");
        var varMessageTitle = (response.Status === 1 ? "Success" : "Error");
        ShowMessage(varMessageTitle, response.Message.Text, varMessageType);
    }
    catch (err) {
        ShowHtmlMessage("Exception", err.message, "error");
    }
};

fnSwitchLanguage = function (language) {
    try {
        var myData = { "Language": language };
        $.ajax({
            type: "POST",
            url: "/Account/SwitchLanguage/",
            contentType: "application/json",
            dataType: "json",
            traditional: true,
            data: JSON.stringify(myData),
            success: function (response) {
                location.reload();
            },
            error: function (response) {
                location.reload();
            }
        });

    }
    catch (err) {
        ShowHtmlMessage("Exception", err.message, "error");
    }
};

fnFillDropDrowns = function (controlId, listData) {
    try {
        var response = null;
        if (typeof listData === "object") {
            response = listData;
        }
        else if (typeof listData === "string") {
            response = JSON.parse(listData);
        }

        $("#" + controlId).html("");
        $("#" + controlId).append($('<option></option>').val("").html('--Select--'));
        $.each(response, function (i, option) {
            if (option.ActiveYn && option.ActiveYn === "N") {
                $("#" + controlId).append($("<option></option>").attr("value", option.Code).attr("value2", option.Value).text(option.Text).attr("disabled", "disabled"));
            }
            else {
                $("#" + controlId).append($("<option></option>").attr("value", option.Code).attr("value2", option.Value).text(option.Text));
            }
        });
    }
    catch (err) {
        ShowHtmlMessage("Exception", err.message, "error");
    }
};

fnAppendDropDrowns = function (controlId, listData) {
    try {
        var response = null;
        if (typeof listData === "object") {
            response = listData;
        }
        else if (typeof listData === "string") {
            response = JSON.parse(listData);
        }

        $("#" + controlId).append($('<option></option>').val("").html('--Select--'));
        $.each(response, function (i, option) {
            if (option.ActiveYn && option.ActiveYn === "N") {
                $("#" + controlId).append($("<option></option>").attr("value", option.Code).attr("value2", option.Value).text(option.Text).attr("disabled", "disabled"));
            }
            else {
                $("#" + controlId).append($("<option></option>").attr("value", option.Code).attr("value2", option.Value).text(option.Text));
            }
        });
    }
    catch (err) {
        ShowHtmlMessage("Exception", err.message, "error");
    }
};


GetFormatedDate = function (dateObject) {
    return moment(dateObject, 'DD/MM/YYYY HH:mm:ss', true).format('DDMMYYYY');
};

fnToggleDiv = function (sender, divarray) {
    if ($(sender).attr("aria-expanded") === "true") {
        $(sender).attr("aria-expanded", "false");
        $(sender).html('');
        $(sender).append("<i class='fa fa-plus' style='margin-right:5px'></i>Expand All");
        $(".with-border").toggleClass("expanded").attr("aria-expanded", "false");
        $(".with-border").toggleClass("expanded").find("i").removeClass("fa fa-minus");
        $(".with-border").toggleClass("expanded").find("i").addClass("fa fa-plus");
        for (var i = 0; i < divarray.length; i++) {
            $("#" + divarray[i].id).removeClass("show");
        }
    }
    else {
        $(sender).attr("aria-expanded", "true");
        $(sender).html('');
        $(sender).append("<i class='fa fa-minus'  style='margin-right:5px'></i>Toggle All");
        $(".with-border").toggleClass("expanded").attr("aria-expanded", "true");
        $(".with-border").toggleClass("expanded").find("i").removeClass("fa fa-plus");
        $(".with-border").toggleClass("expanded").find("i").addClass("fa fa-minus");
        for (var i = 0; i < divarray.length; i++) {
            $("#" + divarray[i].id).addClass("show");
        }
    }

}


fnToggleAll = function (sender, divarray) {
    $(sender).attr("aria-expanded", "false");
    $(sender).html('');
    $(sender).append("<i class='fa fa-plus' style='margin-right:5px'></i>Expand All");
    $(".with-border").toggleClass("expanded").attr("aria-expanded", "false");
    $(".with-border").toggleClass("expanded").find("i").removeClass("fa fa-minus");
    $(".with-border").toggleClass("expanded").find("i").addClass("fa fa-plus");
    for (var i = 0; i < divarray.length; i++) {
        $("#" + divarray[i].id).removeClass("show");
    }
}

fnDefaultDescription = function (sender, targetControl, textLength = 0) {

    try {
        if (targetControl !== null && targetControl !== "") {
            var targetCntrl = $("#" + targetControl);
            if (targetCntrl !== undefined && targetCntrl.val() === "") {
                var subStrLength = (textLength > 0) ? textLength : $(sender).val().length;
                if (subStrLength > $(sender).val().length) {
                    targetCntrl.val($(sender).val());
                }
                else {
                    targetCntrl.val($(sender).val().substring(0, subStrLength));
                }
            }
        }
    } catch (e) {
        return;
    }
};

/* To handle dynamic validation - START */
var validPropertySplitter = "#PROP#";

fnCheckValidationField = function (varConditionType, varArgs) {
    try {
        var counter = 0;
        $.each(varArgs, function (index, value) {
            var argSplit = value.split(validPropertySplitter);
            if (argSplit && argSplit.length === 2) {
                var source = $("*[name='" + argSplit[0] + "']");
                var sourceType = $(source).attr("type");
                if (sourceType === "checkbox") {
                    var argCheckedSts = (argSplit[1] === "true" || argSplit[1] === "Y");
                    if (source && source.length === 1 && $(source).prop("checked") === argCheckedSts) {
                        counter++;
                    }
                }
                else {
                    if (source && source.length === 1 && $(source).val() === argSplit[1]) {
                        counter++;
                    }
                }
            }
        });
        return ((varConditionType === 'AND' && counter === varArgs.length) || (varConditionType === 'OR' && counter >= 1));

    } catch (err) {
        return false;
    }
};

fnValidateRequired = function (sender, varTarget, varConditionType, varMessage, ...varArgs) {
    try {
        var varTargetField = $("*[name='" + varTarget + "']");
        if (varTargetField && varTargetField.length === 1 && varArgs && varArgs.length > 0) {
            if (fnCheckValidationField(varConditionType, varArgs)) {
                $(varTargetField[0]).attr("data-val-required", varMessage);
                $(varTargetField[0]).rules("add", {
                    required: true,
                    messages: {
                        required: varMessage
                    }
                });
            }
            else {
                $(varTargetField[0]).rules("remove", "required");
                $(varTargetField[0]).removeAttr("data-val-required");
            }
            fnSetMandatoryClass(varTarget);
        }
    }
    catch (err) {
        return;
    }
};

fnValidateEmail = function (sender, varTarget, varConditionType, varMessage, ...varArgs) {
    try {
        var varTargetField = $("*[name='" + varTarget + "']");
        if (varTargetField && varTargetField.length === 1 && varArgs && varArgs.length > 0) {
            if (fnCheckValidationField(varConditionType, varArgs)) {
                $(varTargetField[0]).rules("add", {
                    email: true,
                    messages: {
                        email: varMessage
                    }
                });
            }
            else {
                $(varTargetField[0]).rules("remove", "email");
            }
        }
    }
    catch (err) {
        return;
    }
};

fnValidateRegex = function (sender, varTarget, varConditionType, varMessage, varRegex, ...varArgs) {
    try {
        if (varRegex && varRegex !== "") {
            var varTargetField = $("*[name='" + varTarget + "']");
            if (varTargetField && varTargetField.length === 1 && varArgs && varArgs.length > 0) {
                if (fnCheckValidationField(varConditionType, varArgs)) {
                    $(varTargetField[0]).rules("add", {
                        regex: varRegex,
                        messages: {
                            regex: varMessage
                        }
                    });
                }
                else {
                    $(varTargetField[0]).rules("remove", "regex");
                }
            }
        }
    }
    catch (err) {
        return;
    }
};

fnValidateRange = function (sender, varTarget, varConditionType, varMessage, varMinValue, varMaxValue, ...varArgs) {
    try {
        var varTargetField = $("*[name='" + varTarget + "']");
        if (varTargetField && varTargetField.length === 1 && varArgs && varArgs.length > 0) {
            if (fnCheckValidationField(varConditionType, varArgs)) {
                $(varTargetField[0]).rules("add", {
                    required: true,
                    messages: {
                        required: varMessage
                    }
                });
            }
            else {
                $(varTargetField[0]).rules("remove", "required");
            }
        }
    }
    catch (err) {
        return;
    }
};

fnValidateLength = function (sender, varTarget, varConditionType, varMessage, varMinLength, varMaxLength, ...varArgs) {
    try {
        var varTargetField = $("*[name='" + varTarget + "']");
        if (varTargetField && varTargetField.length === 1 && varArgs && varArgs.length > 0) {
            if (fnCheckValidationField(varConditionType, varArgs)) {
                $(varTargetField[0]).rules("add", {
                    required: true,
                    messages: {
                        required: varMessage
                    }
                });
            }
            else {
                $(varTargetField[0]).rules("remove", "required");
            }
        }
    }
    catch (err) {
        return;
    }
};

/* To handle dynamic validation - END */

fnRedirectUrl = function (url) {
    try {
        showPageLoader();
        $(window).attr('location', url);
    }
    catch (err) {
        hidePageLoader();
        ShowHtmlMessage("Exception", err.message, "error");
    }
};

fnNavigateMenu = function (event) {
    try {
        if (!event.ctrlKey) {
            // showPageLoader();
        }
    } catch (e) {
        alert(e.message);
    }
};

formatNumberForDisplay = function (numberToFormat, decialPrecision) {
    var formatter = new Intl.NumberFormat('en-US', {
        //style: 'currency',
        //currency: 'INR',
        maximumFractionDigits: decialPrecision
    });
    return formatter.format(numberToFormat);
};

isNumberKey = function (evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
    if (charCode > 31
        && (charCode < 48 || charCode > 57))
        return false;

    return true;
};



