﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IpmsApp.Helpers
{
    public class ApiDictionary
    {
        #region User

        public const string UserApiAuthenticateUser = "Api/Account/Login";
        public const string UserApiRegisterUser = "Api/Account/Register";
        public const string UserApiValidateUserInfo = "Api/User/Account";
        public const string UserApiUpdateUserPassword = "Api/User/Account";
        public const string UserApiEmailExistsOrNot = "Api/Account/IsEmailExists";

        public const string UserApiConfirmEmail = "Api/Account/ConfirmEmail";
        #endregion

        #region Client

        public const string ClientApiSaveClient = "Api/Client/SaveClient";
        public const string ClientApiUpdateClient = "Api/Client/UpdateClient";
        public const string ClientApiGetClient = "Api/Client/GetClient";
        public const string ClientApiGetClientList = "Api/Client/GetClientList";

        #endregion

        #region Grade

        public const string GradeApiGetGrade = "Api/Grade/GetGrade";
        public const string GradeApiSaveGrade = "Api/Grade/SaveGrade";
        public const string GradeApiUpdateGrade = "Api/Grade/UpdateGrade";
        public const string GradeApiGetGradeList = "Api/Grade/GetGradeList";

        #endregion

        #region Post       
        public const string PostApiSavePost = "Api/Post/SavePost";
        public const string PostApiPostList = "Api/Post/GetPostList";
        public const string PostApiGetPost = "Api/Post/GetPost";
        public const string PostApiUpdatePost = "Api/Post/UpdatePost";
        #endregion
    }
}
