﻿using IpmsApp.Utilities.CustomValidator;
using IpmsEntityModels.Models;
using IpmsShared.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IpmsApp.ViewModels
{
    public class RegisterViewModel
    {
        public RegisterModel Appusers { get; set; }
        
        [Remote(action: "IsEmailInUse", controller: "Account")]
        [ValidEmailDomain(allowedDomain: "ibps.in", ErrorMessage = "Email domain must be ibps.in")]
        public string EmailId { get; set; }
    }
}
