﻿using IpmsShared.Models;
using System.Collections.Generic;


namespace IpmsApp.ViewModels
{
    public class LoginViewModel
    {
        public LoginUserInfo UserLoginModel { get; set; }
    }

    
}
