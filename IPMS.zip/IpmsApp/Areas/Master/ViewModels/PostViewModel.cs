﻿using IpmsEntityModels.Models;
using IpmsShared.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IpmsApp.Areas.Master.ViewModels
{
    public class PostViewModel
    {
        public Post post { get; set; }
        public List<Post> lstPost { get; set; }
        public List<SelectListItem> orgList { get; set; }
        public PageMode CurrentPageMode { get; set; }
    }
}
