﻿using IpmsApp.Utilities.CustomValidator;
using IpmsEntityModels.Models;
using IpmsShared.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace IpmsApp.Areas.Master.ViewModels
{
    public class ClientViewModel
    {
        public Client client { get; set; }
        public List<Client> lstClient { get; set; }
        public PageMode CurrentPageMode { get; set; }

        //[Required(ErrorMessage = "Reqired valid organization name")]
        //[Remote(action: "IsClientNameExists", controller: "client")]
        //[StringLength(100, ErrorMessage = "Organization Name atleast {2} charcter and maximum {1} character", MinimumLength = 4)]
        //[Display(Name = "Name of Organization")]
        //public virtual string OrgnizationName { get; set; }
        //[Required(ErrorMessage = "Reqired valid contact person name")]
        //[StringLength(100, ErrorMessage = "Contact person name length atleast {2} charcter and maximum {1} character", MinimumLength = 4)]
        //[Display(Name = "Name of Contact Person")]
        //public string ContactPersonName { get; set; }
        //[DataType(DataType.EmailAddress)]
        //[Display(Name = "Official Email")]
        //public string Email { get; set; }
        //[Required]
        //[StringLength(15, ErrorMessage = "Mobile no must be {1} in length", MinimumLength = 10)]
        //[Display(Name = "Telephone/Mobile No")]
        //public string MobileNo { get; set; }
        //[Required(ErrorMessage = "Please Select CR Division")]
        //[Display(Name = "Tag With Section")]
        //[ValidSelectedItem(1, ErrorMessage = "Plese select a valid section")]
        //public int TagWith { get; set; }
        public List<SelectListItem> lstQuarter { get; set; }

        //public ClientCreateViewModel()
        //{
        //    SectionList = new SelectList(new List<SelectListItem>
        //                {
        //                    new SelectListItem { Text = "Select Section", Value = "-1"},
        //                    new SelectListItem {  Text = "CR-I", Value = "1"},
        //                    new SelectListItem {  Text = "CR-II", Value = "2"},
        //                }, "Value", "Text", 1);
        //}
    }
}
