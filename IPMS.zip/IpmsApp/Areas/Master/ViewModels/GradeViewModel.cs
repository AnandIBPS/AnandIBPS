﻿using IpmsEntityModels.Models;
using IpmsShared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IpmsApp.Areas.Master.ViewModels
{
    public class GradeViewModel
    {
        public Grade grade { get; set; }
        public List<Grade> lstGrade { get; set; }
        public PageMode CurrentPageMode { get; set; }
    }
}
