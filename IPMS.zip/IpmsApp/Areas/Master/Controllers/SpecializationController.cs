﻿//using IpmsEntityContext.Data.IRepository;
using IpmsEntityModels.Models;
using IpmsShared.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace IpmsApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SpecializationController
    {
    }
}
