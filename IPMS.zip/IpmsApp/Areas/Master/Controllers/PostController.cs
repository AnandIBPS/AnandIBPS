﻿using IpmsApp.Areas.Master.ViewModels;
using IpmsApp.Helpers;
using IpmsEntityModels.Models;
using IpmsShared;
using IpmsShared.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;

namespace IpmsApp.Areas.Master.Controllers
{
    [Area("Master")]
    [Authorize(AuthorizationType.Anonymous)]
    public class PostController : BaseController
    {
        private readonly ISession _session;
        private readonly IConfiguration _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IWebHostEnvironment _webHostEnvironment;
        private readonly ApiHelper _apiHelper;
        private readonly ILogger<PostController> _logger;
        readonly IStringLocalizer<SharedResource> _sharedLocalizer;
        readonly IStringLocalizer<PostViewModel> _Localizer;
        public PostController(IConfiguration configuration,
               IHttpContextAccessor httpContextAccessor,
               IWebHostEnvironment webHostEnvironment,
               ILogger<PostController> logger,
               ApiHelper apiHelper, IStringLocalizer<SharedResource> sharedLocalizer, IStringLocalizer<PostViewModel> Localizer) : base(configuration, httpContextAccessor)
        {
            _configuration = configuration;
            _httpContextAccessor = httpContextAccessor;
            _session = httpContextAccessor.HttpContext.Session;
            _webHostEnvironment = webHostEnvironment;
            _apiHelper = apiHelper;
            _sharedLocalizer = sharedLocalizer;
            _logger = logger;
            _Localizer = Localizer;
        }
        public async Task<IActionResult> Post(int id)
        {
            PostViewModel model = new PostViewModel()
            {
                post = new Post(),
                CurrentPageMode = PageMode.Insert,
                lstPost = new List<Post>(),
                orgList = await OrganizationListsForDropDown()

            };
            if (id != 0)
            {
                using HttpResponseMessage httpResponse = await _apiHelper.ApiClient.GetAsync($"{ApiDictionary.PostApiGetPost}/{id}");
                if (httpResponse != null && httpResponse.IsSuccessStatusCode)
                {
                    model.post = await httpResponse.Content.ReadFromJsonAsync<Post>();
                    model.CurrentPageMode = PageMode.Update;
                }
                else
                {
                    AppNotification.ShowMessage(this, _sharedLocalizer["FailedToProcess"], MessageType.Error);
                }
            }
            return View("Post", model);
        }

        [HttpPost]
        public async Task<IActionResult> Post(PostViewModel model)
        {

            try
            {
                model.post.CcCrBy = _session.UserId();
                if (ModelState.IsValid && model.post != null)
                {

                    if (model.CurrentPageMode == PageMode.Insert)
                    {
                        using HttpResponseMessage httpResponse = await _apiHelper.ApiClient.PostAsJsonAsync(ApiDictionary.PostApiSavePost, model.post);
                        if (httpResponse != null && httpResponse.IsSuccessStatusCode)
                        {
                            var result = await httpResponse.Content.ReadAsStringAsync();
                            var varApiResponse = JsonConvert.DeserializeObject<ApiResponse>(result);
                            if (varApiResponse.Status != 0)
                            {
                                AppNotification.ShowMessage(this, _Localizer["SaveSuccess"], MessageType.Success);
                                return Redirect($"/Master/Post/PostList");
                            }
                            else
                            {
                                AppNotification.ShowMessage(this, _sharedLocalizer["FailedToProcess"], MessageType.Error);
                                return Redirect($"/Master/Post/Post");
                            }
                        }
                    }
                    else if (model.CurrentPageMode == PageMode.Update)
                    {
                        using HttpResponseMessage httpResponse = await _apiHelper.ApiClient.PostAsJsonAsync(ApiDictionary.PostApiUpdatePost, model.post);
                        if (httpResponse != null && httpResponse.IsSuccessStatusCode)
                        {
                            var result = await httpResponse.Content.ReadAsStringAsync();
                            var varApiResponse = JsonConvert.DeserializeObject<ApiResponse>(result);
                            if (varApiResponse.Status != 0)
                            {
                                AppNotification.ShowMessage(this, _Localizer["SaveSuccess"], MessageType.Success);
                                return Redirect($"/Master/Post/PostList");
                            }
                            else
                            {
                                AppNotification.ShowMessage(this, _sharedLocalizer["FailedToProcess"], MessageType.Error);
                                return Redirect($"/Master/Post/PostList");
                            }
                        }
                    }
                }
                else
                {
                    AppNotification.ShowMessage(this, _sharedLocalizer["FailedToProcess"], MessageType.Error);
                }
                return View("Post", model);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Post-PostMethod");
                return BadRequest(ex);
            }
        }

        #region Listing
        public async Task<IActionResult> PostList()
        {
            PostViewModel model = new PostViewModel()
            {
                post = new Post(),
                CurrentPageMode = PageMode.Insert,
                lstPost = new List<Post>()

            };
            using HttpResponseMessage httpResponse = await _apiHelper.ApiClient.GetAsync($"{ApiDictionary.PostApiPostList}");
            if (httpResponse != null && httpResponse.IsSuccessStatusCode)
            {
                model.lstPost = await httpResponse.Content.ReadFromJsonAsync<List<Post>>();
            }
            else
            {
                AppNotification.ShowMessage(this, _sharedLocalizer["FailedToProcess"], MessageType.Error);
            }
            return View("PostList", model);
        }
        #endregion

        #region Private Method
        private async Task<List<SelectListItem>> OrganizationListsForDropDown()
        {
            List<Client> clntlists = new List<Client>();
            List<SelectListItem> orglists = new List<SelectListItem>();
            try
            {
                using HttpResponseMessage httpResponse = await _apiHelper.ApiClient.GetAsync($"{ApiDictionary.ClientApiGetClientList}");
                if (httpResponse != null && httpResponse.IsSuccessStatusCode)
                {
                    clntlists = await httpResponse.Content.ReadFromJsonAsync<List<Client>>();

                    if (clntlists.Count > 0)
                    {
                        foreach (Client org in clntlists)
                        {
                            SelectListItem ddl = new SelectListItem();
                            ddl.Text = org.OrgnizationName;
                            ddl.Value = Convert.ToString(org.Id);
                            orglists.Add(ddl);
                        }
                    }
                }
                else
                {
                    AppNotification.ShowMessage(this, _sharedLocalizer["FailedToProcess"], MessageType.Error);
                }
            }
            catch (Exception ex)
            {

            }

            return orglists;
        }
        #endregion
    }
}
