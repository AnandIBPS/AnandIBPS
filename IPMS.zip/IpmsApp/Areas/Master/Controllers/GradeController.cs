﻿using IpmsApp.Areas.Master.ViewModels;
using IpmsApp.Helpers;
using IpmsEntityModels.Models;
using IpmsShared;
using IpmsShared.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;

namespace IpmsApp.Areas.Master.Controllers
{
    [Area("Master")]
    [Authorize(AuthorizationType.Anonymous)]
    public class GradeController : BaseController
    {
        private readonly ISession _session;
        private readonly IConfiguration _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IWebHostEnvironment _webHostEnvironment;
        private readonly ApiHelper _apiHelper;
        private readonly ILogger<GradeController> _logger;
        readonly IStringLocalizer<SharedResource> _sharedLocalizer;
        readonly IStringLocalizer<GradeViewModel> _Localizer;
        public GradeController(IConfiguration configuration,
               IHttpContextAccessor httpContextAccessor,
               IWebHostEnvironment webHostEnvironment,
               ILogger<GradeController> logger,
               ApiHelper apiHelper, IStringLocalizer<SharedResource> sharedLocalizer, IStringLocalizer<GradeViewModel> Localizer) : base(configuration, httpContextAccessor)
        {
            _configuration = configuration;
            _httpContextAccessor = httpContextAccessor;
            _session = httpContextAccessor.HttpContext.Session;
            _webHostEnvironment = webHostEnvironment;
            _apiHelper = apiHelper;
            _sharedLocalizer = sharedLocalizer;
            _logger = logger;
            _Localizer = Localizer;
        }
        public async Task<IActionResult> Grade(int id)
        {
            GradeViewModel model = new GradeViewModel()
            {
                grade = new Grade(),
                CurrentPageMode = PageMode.Insert,
                lstGrade = new List<Grade>()

            };
            if (id != 0)
            {
                using HttpResponseMessage httpResponse = await _apiHelper.ApiClient.GetAsync($"{ApiDictionary.GradeApiGetGrade}/{id}");
                if (httpResponse != null && httpResponse.IsSuccessStatusCode)
                {
                    model.grade = await httpResponse.Content.ReadFromJsonAsync<Grade>();
                    model.CurrentPageMode = PageMode.Update;
                }
                else
                {
                    AppNotification.ShowMessage(this, _sharedLocalizer["FailedToProcess"], MessageType.Error);
                }
            }
            return View("Grade", model);
        }

        [HttpPost]
        public async Task<IActionResult> Grade(GradeViewModel model)
        {
            try
            {
                if (ModelState.IsValid && model.grade != null)
                {

                    if (model.CurrentPageMode == PageMode.Insert)
                    {
                        using HttpResponseMessage httpResponse = await _apiHelper.ApiClient.PostAsJsonAsync(ApiDictionary.GradeApiSaveGrade, model.grade);
                        if (httpResponse != null && httpResponse.IsSuccessStatusCode)
                        {
                            var result = await httpResponse.Content.ReadAsStringAsync();
                            var varApiResponse = JsonConvert.DeserializeObject<Grade>(result);
                            if (varApiResponse != null)
                            {
                                AppNotification.ShowMessage(this, _Localizer["SaveSuccess"], MessageType.Success);
                                return Redirect($"/Master/Grade/Grade/{model.grade.GradeId}");
                            }
                            else
                            {
                                AppNotification.ShowMessage(this, _sharedLocalizer["FailedToProcess"], MessageType.Error);
                            }
                        }
                    }
                    else if (model.CurrentPageMode == PageMode.Update)
                    {
                        using HttpResponseMessage httpResponse = await _apiHelper.ApiClient.PostAsJsonAsync(ApiDictionary.GradeApiUpdateGrade, model.grade);
                        if (httpResponse != null && httpResponse.IsSuccessStatusCode)
                        {
                            var result = await httpResponse.Content.ReadAsStringAsync();
                            var varApiResponse = JsonConvert.DeserializeObject<Grade>(result);
                            if (varApiResponse != null)
                            {
                                AppNotification.ShowMessage(this, _Localizer["UpdateSuccess"], MessageType.Success);
                                return Redirect($"/Master/Grade/Grade/{model.grade.GradeId}");
                            }
                            else
                            {
                                AppNotification.ShowMessage(this, _sharedLocalizer["FailedToProcess"], MessageType.Error);
                            }
                        }
                    }
                }
                else
                {
                    AppNotification.ShowMessage(this, _sharedLocalizer["FailedToProcess"], MessageType.Error);
                }
                return View("Grade", model);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Grade-PostMethod");
                return BadRequest(ex);
            }
        }

        #region Listing
        public async Task<IActionResult> GradeList()
        {
            GradeViewModel model = new GradeViewModel()
            {
                grade = new Grade(),
                CurrentPageMode = PageMode.Insert,
                lstGrade = new List<Grade>()

            };
            using HttpResponseMessage httpResponse = await _apiHelper.ApiClient.GetAsync($"{ApiDictionary.GradeApiGetGradeList}");
            if (httpResponse.StatusCode == System.Net.HttpStatusCode.OK)
            {
                if (httpResponse != null && httpResponse.IsSuccessStatusCode)
                {
                    model.lstGrade = await httpResponse.Content.ReadFromJsonAsync<List<Grade>>();
                }
                else
                {
                    AppNotification.ShowMessage(this, _sharedLocalizer["FailedToProcess"], MessageType.Error);
                }

            }
            else
            {
                return Redirect($"/Error/{(int)httpResponse.StatusCode}");
            }

            return View("GradeList", model);
        }
        #endregion
    }
}
