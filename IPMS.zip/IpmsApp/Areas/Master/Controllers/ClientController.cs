﻿using IpmsApp.Areas.Master.ViewModels;
using IpmsApp.Helpers;
using IpmsEntityModels.Models;
using IpmsShared;
using IpmsShared.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;

namespace IpmsApp.Areas.Master.Controllers
{
    [Area("Master")]
    [Authorize(AuthorizationType.Anonymous)]
    public class ClientController : BaseController
    {
        private readonly ISession _session;
        private readonly IConfiguration _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IWebHostEnvironment _webHostEnvironment;
        private readonly ApiHelper _apiHelper;
        private readonly ILogger<ClientController> _logger;
        readonly IStringLocalizer<SharedResource> _sharedLocalizer;
        readonly IStringLocalizer<ClientViewModel> _Localizer;
        public ClientController(IConfiguration configuration,
               IHttpContextAccessor httpContextAccessor,
               IWebHostEnvironment webHostEnvironment,
               ILogger<ClientController> logger,
               ApiHelper apiHelper, IStringLocalizer<SharedResource> sharedLocalizer, IStringLocalizer<ClientViewModel> Localizer) : base(configuration, httpContextAccessor)
        {
            _configuration = configuration;
            _httpContextAccessor = httpContextAccessor;
            _session = httpContextAccessor.HttpContext.Session;
            _webHostEnvironment = webHostEnvironment;
            _apiHelper = apiHelper;
            _sharedLocalizer = sharedLocalizer;
            _logger = logger;
            _Localizer = Localizer;
        }
        public async Task<IActionResult> Client(int id)
        {
            ClientViewModel model = new ClientViewModel()
            {
                client = new Client(),
                CurrentPageMode = PageMode.Insert,
                lstQuarter = new List<SelectListItem>()

            };
            _ = SetDropdownList(model);
            if (id != 0)
            {
                using HttpResponseMessage httpResponse = await _apiHelper.ApiClient.GetAsync($"{ApiDictionary.ClientApiGetClient}/{id}");
                if (httpResponse != null && httpResponse.IsSuccessStatusCode)
                {
                    model.client = await httpResponse.Content.ReadFromJsonAsync<Client>();
                    model.CurrentPageMode = PageMode.Update;
                }
                else
                {
                    AppNotification.ShowMessage(this, _sharedLocalizer["FailedToProcess"], MessageType.Error);
                }
            }
            return View("Client", model);
        }

        [HttpPost]
        public async Task<IActionResult> Client(ClientViewModel model)
        {
            try
            {
                model.client.CcCrBy = _session.UserId();
                if (ModelState.IsValid && model.client != null)
                {

                    if (model.CurrentPageMode == PageMode.Insert)
                    {
                        using HttpResponseMessage httpResponse = await _apiHelper.ApiClient.PostAsJsonAsync(ApiDictionary.ClientApiSaveClient, model.client);
                        if (httpResponse != null && httpResponse.IsSuccessStatusCode)
                        {
                            var result = await httpResponse.Content.ReadAsStringAsync();
                            var varApiResponse = JsonConvert.DeserializeObject<Client>(result);
                            if (varApiResponse != null)
                            {
                                AppNotification.ShowMessage(this, _sharedLocalizer["SaveSuccess"], MessageType.Success);
                                return Redirect($"/Master/Client/Clientlist");
                            }
                            else
                            {
                                AppNotification.ShowMessage(this, _sharedLocalizer["FailedToProcess"], MessageType.Error);
                            }
                        }
                    }
                    else if (model.CurrentPageMode == PageMode.Update)
                    {
                        using HttpResponseMessage httpResponse = await _apiHelper.ApiClient.PostAsJsonAsync(ApiDictionary.ClientApiUpdateClient, model.client);
                        if (httpResponse != null && httpResponse.IsSuccessStatusCode)
                        {
                            var result = await httpResponse.Content.ReadAsStringAsync();
                            var varApiResponse = JsonConvert.DeserializeObject<Client>(result);
                            if (varApiResponse != null)
                            {
                                AppNotification.ShowMessage(this, _sharedLocalizer["UpdateSuccess"], MessageType.Success);
                                return Redirect($"/Master/Client/Client/{model.client.Id}");
                            }
                            else
                            {
                                AppNotification.ShowMessage(this, _sharedLocalizer["FailedToProcess"], MessageType.Error);
                            }
                        }
                    }
                }
                else
                {
                    AppNotification.ShowMessage(this, _sharedLocalizer["FailedToProcess"], MessageType.Error);
                }
                _ = SetDropdownList(model);
                return View("Client", model);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Client-PostMethod");
                return BadRequest(ex);
            }
        }

        #region Private Methods
        private ClientViewModel SetDropdownList(ClientViewModel model)
        {
            try
            {

                model.lstQuarter.Add(new SelectListItem() { Text = "Select Section", Value = "-1" });
                model.lstQuarter.Add(new SelectListItem() { Text = "CR-I", Value = "1" });
                model.lstQuarter.Add(new SelectListItem() { Text = "CR-II", Value = "2" });

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Client-SetDropdownList");
            }
            return model;
        }
        #endregion

        #region Listing
        public async Task<IActionResult> ClientList()
        {
            ClientViewModel model = new ClientViewModel()
            {
                client = new Client(),
                CurrentPageMode = PageMode.Insert,
                lstQuarter = new List<SelectListItem>(),
                lstClient = new List<Client>()

            };
            using HttpResponseMessage httpResponse = await _apiHelper.ApiClient.GetAsync($"{ApiDictionary.ClientApiGetClientList}");
            if (httpResponse != null && httpResponse.IsSuccessStatusCode)
            {
                model.lstClient = await httpResponse.Content.ReadFromJsonAsync<List<Client>>();
            }
            else
            {
                return Redirect($"/Error/{(int)httpResponse.StatusCode}");
                AppNotification.ShowMessage(this, _sharedLocalizer["FailedToProcess"], MessageType.Error);
            }
            return View("ClientList", model);
        }
        #endregion
    }
}
